package com.example.assign2
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.border
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import com.example.assign2.R.drawable.img_4973
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.annotation.DrawableRes
import com.example.assign2.R.drawable.img_4982
import com.example.assign2.ui.theme.Assign2Theme


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Assign2Theme {
                // Navigation state
                var currentPage by remember { mutableStateOf("opening") }

                when (currentPage) {
                    "opening" -> OpeningPage(onContinueClicked = { currentPage = "main" })
                    "main" -> {
                        // Assuming ImageViewer displays your images
                        ImageViewer(imageList = listOf(R.drawable.img_4982, R.drawable.img_4983, R.drawable.img_4973)) // Add your images here
                        Button(onClick = { currentPage = "closing" }) {
                            Text("Done")
                        }
                    }
                    "closing" -> ClosingPage(onRestartClicked = { currentPage = "opening" })
                }
            }
        }
    }
}




// Opening Page
@Composable
fun OpeningPage(onContinueClicked: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center, modifier = Modifier.fillMaxSize()) {
        Text("Welcome to the Feline Art Gallery")
        Button(onClick = onContinueClicked) {
            Text("Enter")
        }
    }
}




// Closing Page
@Composable
fun ClosingPage(onRestartClicked: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center, modifier = Modifier.fillMaxSize()) {
        Text("Thank you for your visit!")
        Button(onClick = onRestartClicked) {
            Text("View again")
        }
    }
}




//viewer  for images , next and previous  buttons
@Composable
fun ImageViewer(imageList: List<Int>) {
    var currentIndex by remember { mutableStateOf(0) }

    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(id = imageList[currentIndex]),
            contentDescription = "Feline  Artwork",
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            contentScale = ContentScale.FillWidth
        )




        Row(modifier = Modifier.padding(16.dp)) {
            Button(onClick = {
                // Previous Button
                currentIndex = if (currentIndex > 0) {
                    currentIndex - 1
                } else {
                    imageList.lastIndex
                }
            }) {
                Text("Previous")
            }

            Spacer(Modifier.width(8.dp))

            Button(onClick = {
                // Next Button
                currentIndex = if (currentIndex < imageList.lastIndex) {
                    currentIndex + 1
                } else 0
            }) {
                Text("Next")
            }
        }
    }
}
